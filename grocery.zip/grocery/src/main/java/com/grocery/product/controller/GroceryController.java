package com.grocery.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grocery.product.model.Grocery;
import com.grocery.product.service.GroceryService;

@RestController
@RequestMapping("Grocery")
public class GroceryController {

	@Autowired
	GroceryService groceryService;

	@PostMapping(value = "/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public Grocery save(@RequestBody Grocery grocery) {

		return groceryService.add(grocery);
	}

	@GetMapping(value = "/getAllProducts")
	public List<Grocery> getAll() {
		return groceryService.getAllProduct();
	}

	@PutMapping(value = "/update/{id}", consumes = "application/json")
	public Grocery update(@PathVariable Long id, @RequestBody Grocery grocery) {

		return groceryService.update(id, grocery);
	}

	@DeleteMapping(value = "/delete/{id}")
	public String delete(@PathVariable Long id) {

		return groceryService.delete(id);
	}

	@GetMapping(value = "/search")
	public List<Grocery> search(@RequestParam String productName) {
		return groceryService.search(productName);
	}
}
