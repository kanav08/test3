package com.grocery.product.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.grocery.product.model.Grocery;

@Component
public interface GroceryDao extends Repository<Grocery, Long> {

	public Grocery save(Grocery grocery);

	@Query("SELECT g From Grocery g WHERE product_name like %:productName%")
	public List<Grocery> findByName(@Param(value = "productName") String productName);
	//or
	//List<Hero> findByNameIgnoreCaseContaining(String name);

	public Grocery findById(Long id);

	List<Grocery> findAllByOrderByIdAsc();

	Long deleteById(Long id);
}
