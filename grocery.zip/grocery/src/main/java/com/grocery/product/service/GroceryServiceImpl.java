package com.grocery.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.product.dao.GroceryDao;
import com.grocery.product.model.Grocery;

@Service
public class GroceryServiceImpl implements GroceryService {

	@Autowired
	GroceryDao groceryDao;

	@Override
	public Grocery add(Grocery grocery) {
		if (grocery != null) {
			return groceryDao.save(grocery);
		}
		return null;
	}

	@Override
	public List<Grocery> getAllProduct() {
		return groceryDao.findAllByOrderByIdAsc();
	}

	@Override
	public Grocery update(Long id, Grocery grocery) {
		Grocery groceryInDb = groceryDao.findById(id);
		if (groceryInDb != null) {
			groceryInDb.setProductName(grocery.getProductName());
			groceryInDb.setPrice(grocery.getPrice());
			groceryInDb.setQuantity(grocery.getQuantity());
			groceryInDb = groceryDao.save(groceryInDb);
		}
		return groceryInDb;
	}

	@Override
	public String delete(Long id) {
		try {
			groceryDao.deleteById(id);
			return "Record deleted Successfully";
		} catch (Exception e) {
			return "Record not found";
		}
	}

	@Override
	public List<Grocery> search(String name) {
		return groceryDao.findByName(name);
	}

}
