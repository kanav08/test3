package com.grocery.product.service;

import java.util.List;

import com.grocery.product.model.Grocery;

public interface GroceryService {

	public Grocery add(Grocery grocery);

	public List<Grocery> getAllProduct();

	public Grocery update(Long id, Grocery grocery);

	public String delete(Long id);

	public List<Grocery> search(String name);
}
